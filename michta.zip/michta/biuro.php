<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poznaj Europe</title>
    <link rel="stylesheet" href="style9.css">
</head>
<body>
    <header class="baner">
        <h1>biuro podrozy </h1>
    </header>
    <main>
        <section class="lewy ">
            <table>
                <tr>
                    <td> warszawas </td>
                    <td> od 600 zl  </td>
                </tr>
                <tr>
                    <td> wenecja </td>
                    <td> od 1200zl </td>
                </tr>
                <tr>
                    <td> paryz </td>
                    <td> od 1200 zl </td>
                </tr>
            </table>
        </section>
        <section class="srodkowy ">
            <h2>w tym roku jedziemy do </h2>
            <?php
            $polaczenie = mysqli_connect("localhost", "root" , "", "podroze");
             $zapytanie = "SELECT zdjecia.nazwaPliku , zdjecia.podpis FROM zdjecia ORDER BY podpis ASC;";
            $odp = mysqli_query($polaczenie, $zapytanie);
            while ($row = mysqli_fetch_row( $odp)) {
            echo "<img src='$row[0]' alt='$row[1]' >"; 
            }
?>
        </section>
        <section class="prawy ">
            <h2> kontakt</h2>
            <a href="biuro@wycieczki.pl" > napisz do nas </a>
            <p>telefon 444555666</p>
        </section>
        <section class="blokZdanymi ">
            <h3> w poprzednich latach bylismy ...</h3>
            
            <?php
            $polaczenie = mysqli_connect("localhost", "root" , "", "podroze");
             $zapytanie = "SELECT cel , wycieczki.dataWyjazdu FROM wycieczki WHERE dostepna = 0;";
            $odp = mysqli_query($polaczenie, $zapytanie);
            echo " <ol>";
            while ($row = mysqli_fetch_row( $odp)) {
            echo "<li>Dnia '$row[0]' pojechaliśmy do '$row[1]', </li>"; 
            }
            echo"</ol>" ;
            ?>
     
            <ol>
                
               
            </ol>
        </section>
      
    
    </main>
    <footer class="stopka">
        <p> strone wykonal 0631311314515151</p>
    </footer>
</body>
</html>